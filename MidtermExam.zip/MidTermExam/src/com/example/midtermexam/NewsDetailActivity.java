package com.example.midtermexam;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

/**
 * 
 * @author Manju Raghavendra Bellamkonda
 *
 */
public class NewsDetailActivity extends Activity {

	TextView title, pubDate, description;
	ImageView iv;
	static final String KEY_WEB_VIEW_URL = "web_view";
	NewsItem item;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news_detail);
		loadAllViews();
		item = (NewsItem) getIntent().getExtras().getSerializable(
				NewsActivity.KEY_NEWS_ITEM);
		title.setText(item.getTitle());
		Date date1=item.getPublishedDate();
		SimpleDateFormat df=new SimpleDateFormat("MM/dd/yyyy HH:MM");
		pubDate.setText(df.format(date1));
		description.setText(item.getDescription());
		if(item.getMediaUrl()!=null && item.getMediaUrl().size()>0)
		{
		MediaAttributes att = item.getMediaUrl().get(0);
		Picasso.with(this).load(att.getUrl()).resize(500, 500)
				.error(R.drawable.photo_not_found).into(iv);
		}
		else
		{
			iv.setImageResource(R.drawable.photo_not_found);
		}
		iv.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getBaseContext(),
						NewsWebViewActivity.class);
				intent.putExtra(KEY_WEB_VIEW_URL, item.getLink());
				startActivity(intent);

			}
		});
	}

	private void loadAllViews() {
		title = (TextView) findViewById(R.id.textView1);
		pubDate = (TextView) findViewById(R.id.textView2);
		description = (TextView) findViewById(R.id.textView4);
		iv = (ImageView) findViewById(R.id.imageView1);
	}
}
