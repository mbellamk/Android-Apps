package com.example.midtermexam;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 * 
 * @author Manju Raghavendra Bellamkonda
 *
 */
public class NewsItem implements Serializable {
	String title, description, link, guid, pubDate;
	ArrayList<MediaAttributes> mediaUrl;
	Date publishedDate;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getPubDate() {
		return pubDate;
	}

	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
		this.publishedDate=new Date(pubDate);
	}

	public ArrayList<MediaAttributes> getMediaUrl() {
		return mediaUrl;
	}

	public void setMediaUrl(ArrayList<MediaAttributes> mediaUrl) {
		this.mediaUrl = mediaUrl;
	}

	public void addMediaUrl(MediaAttributes media) {
		this.mediaUrl.add(media);
	}

	
	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	@Override
	public String toString() {
		return title;
	}

}
