package com.example.midtermexam;

import java.io.Serializable;

/**
 * 
 * @author Manju Raghavendra Bellamkonda
 *
 */
public class MediaAttributes implements Serializable{
	Integer height, width;
	String url;

	public Integer getHeight() {
		return height;
	}

	public void setHeight(String height) {
		if(!height.equals(""))
		this.height = Integer.parseInt(height);
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(String width) {
		if(!width.equals(""))
		this.width = Integer.parseInt(width);
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
