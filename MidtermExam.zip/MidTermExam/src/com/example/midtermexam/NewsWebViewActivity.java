package com.example.midtermexam;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.RelativeLayout;

/**
 * 
 * @author Manju Raghavendra Bellamkonda
 *
 */
public class NewsWebViewActivity extends Activity {

	WebView wv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news_web_view);
		wv=(WebView) findViewById(R.id.webView1);
		wv.loadUrl(getIntent().getExtras().getString(NewsDetailActivity.KEY_WEB_VIEW_URL));
	}
}
