package com.example.midterms2015;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.util.Log;


public class NewsPullParser {

	static class BBCPullParser {
		static ArrayList<HeadLineSource> parseFlickrData(InputStream in)
				throws XmlPullParserException, IOException {
			
			ArrayList<HeadLineSource> hlSource = null;
			
			XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
			parser.setInput(in, "UTF-8");
			
			int event = parser.getEventType();
			HeadLineSource item = null;
			
			StringBuilder text = new StringBuilder();
			while (event != XmlPullParser.END_DOCUMENT) {
				switch (event) {
				case XmlPullParser.START_DOCUMENT:
					hlSource = new ArrayList<HeadLineSource>();
					break;
				case XmlPullParser.START_TAG:
					if (parser.getName().equals("item")) {
						item = new HeadLineSource();
					} else if (item != null && parser.getName().equals("title")) {
						text = new StringBuilder();
					} else if (item != null
							&& parser.getName().equals("description")) {
						text = new StringBuilder();
					} else if (item != null && parser.getName().equals("link")) {
						text = new StringBuilder();
					} else if (item != null && parser.getName().equals("guid")) {
						text = new StringBuilder();
					} else if (item != null
							&& parser.getName().equals("pubDate")) {
						text = new StringBuilder();
					}

					break;
				case XmlPullParser.END_TAG:
					if (item != null && parser.getName().equals("title")) {
						item.setTitle(text.toString());
						hlSource.add(item);
					}else if (item != null && parser.getName().equals("description")) {
						item.setDescription(text.toString());
					} else if (item != null && parser.getName().equals("link")) {
						item.setLink(text.toString());
					} else if (item != null && parser.getName().equals("guid")) {
						item.setGuid(text.toString());
					} else if (item != null
							&& parser.getName().equals("pubDate")) {
						item.setPubDate(text.toString());
					} 
					break;
				case XmlPullParser.TEXT:
					text.append(parser.getText());
					break;
				}

				event = parser.next();
			}
			
			return hlSource;

		}
	}
}
