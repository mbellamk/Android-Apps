package com.example.midterms2015;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.xmlpull.v1.XmlPullParserException;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class NewsActivity extends Activity {

	ArrayList<HeadLineSource> hlsArrayList;
	ListView lv;
	ProgressBar pb;
	ArrayAdapter<HeadLineSource> adapter;
	TextView tvLoadNews;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news);
		
		lv = (ListView) findViewById(R.id.listView1);
		pb = (ProgressBar) findViewById(R.id.progressBar1);
		tvLoadNews = (TextView) findViewById(R.id.textView1);
		new loadNewsAsyncTask().execute(getIntent().getExtras().getString(
				MainActivity.MYURL_KEY));

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.news, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_sort_title_a2z) {
			Collections.sort(hlsArrayList, new Comparator<HeadLineSource>() {

				@Override
				public int compare(HeadLineSource object1, HeadLineSource object2) {
					return object1.getTitle().compareTo(object2.getTitle());
				}

			});
			return true;
		} else if (id == R.id.action_sort_title_z2a) {
			Collections.sort(hlsArrayList, new Comparator<HeadLineSource>() {

				@Override
				public int compare(HeadLineSource object1, HeadLineSource object2) {
					return object2.getTitle().compareTo(object1.getTitle());
				}

			});
			return true;
		} else if (id == R.id.action_sort_pubdate_ascending) {
			Collections.sort(hlsArrayList, new Comparator<HeadLineSource>() {

				@Override
				public int compare(HeadLineSource object1, HeadLineSource object2) {
					// TODO Auto-generated method stub
					return 0;
				}

			});
			return true;
		} else if (id == R.id.action_sort_pubdate_descending) {
			Collections.sort(hlsArrayList, new Comparator<HeadLineSource>() {

				@Override
				public int compare(HeadLineSource object1, HeadLineSource object2) {
					// TODO Auto-generated method stub
					return 0;
				}

			});
			return true;
		}
		adapter = new ArrayAdapter<HeadLineSource>(NewsActivity.this,android.R.layout.simple_list_item_1, hlsArrayList);
		lv.setAdapter(adapter);
		return super.onOptionsItemSelected(item);
	}

	public class loadNewsAsyncTask extends
			AsyncTask<String, Void, ArrayList<HeadLineSource>> {

		@Override
		protected ArrayList<HeadLineSource> doInBackground(String... params) {
			URL url;
			try {
				url = new URL(params[0]);
				HttpURLConnection con = (HttpURLConnection) url
						.openConnection();
				con.connect();
				return NewsPullParser.BBCPullParser.parseFlickrData(con.getInputStream());
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (XmlPullParserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pb.setVisibility(View.VISIBLE);
			tvLoadNews.setVisibility(View.VISIBLE);
			lv.setVisibility(View.INVISIBLE);

		}

		@Override
		protected void onPostExecute(ArrayList<HeadLineSource> result) {
			super.onPostExecute(result);
			hlsArrayList = result;
			adapter = new ArrayAdapter<HeadLineSource>(NewsActivity.this, android.R.layout.simple_list_item_1, hlsArrayList);
			adapter.setNotifyOnChange(true);
			lv.setAdapter(adapter);
			pb.setVisibility(View.INVISIBLE);
			tvLoadNews.setVisibility(View.INVISIBLE);
			lv.setVisibility(View.VISIBLE);
			

		}

		
	}
}
