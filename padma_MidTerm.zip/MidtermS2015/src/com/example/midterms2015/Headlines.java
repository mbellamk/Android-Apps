package com.example.midterms2015;

import android.R.string;

public class Headlines {
	
	String hlName;
	String newsurl;
	
	@Override
	public String toString() {
		return  hlName ;
	}

	
	public Headlines(String hlName, String newsurl) {
		super();
		this.hlName = hlName;
		this.newsurl = newsurl;
		
	}

	public String getHlName() {
		return hlName;
	}

	public void setHlName(String hlName) {
		this.hlName = hlName;
	}

	public String getNewsurl() {
		return newsurl;
	}

	public void setNewsurl(String newsurl) {
		this.newsurl = newsurl;
	}
	

}
