package com.example.inclass;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Assignment No: InClass Assignment02 - Part A 
 * File Name: MainActivity.java 
 * 
 * Team Members: 
 * 1. Manju Raghavendra Bellamkonda 
 * 2. Prem kumar Murugesan
 * 3. Madhavi bhat
 */
public class MainActivity extends Activity implements View.OnClickListener{

	TextView tv;
	EditText et1;
	EditText et2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tv=(TextView) findViewById(R.id.textView2);
		et1=(EditText) findViewById(R.id.editText1);
		et2=(EditText) findViewById(R.id.editText2);
		Log.d("Inclass2A", "@@@@@@Inside OnCreate");
	
		
		Button add= (Button) findViewById(R.id.button1);
		add.setOnClickListener(this);
		Button subtract= (Button) findViewById(R.id.button2);
		subtract.setOnClickListener(this);
		Button multiply= (Button) findViewById(R.id.button3);
		multiply.setOnClickListener(this);
		Button divide= (Button) findViewById(R.id.button4);
		divide.setOnClickListener(this);
		Button clearAll= (Button) findViewById(R.id.button5);
		clearAll.setOnClickListener(this);
		
		
	}

	@Override
	public void onClick(View v) {
		if(v.getId()==R.id.button5)
		{
			Log.d("Inclass2A", "Inside Onclick");
			et1.setText(null);
			et2.setText(null);
			tv.setText(null);
		}
		else if(et1.getText().toString().trim().equals("") || et2.getText().toString().trim().equals("")|| et1.getText().toString().trim().equals("-") || et2.getText().toString().trim().equals("-")|| et1.getText().toString().trim().equals("+") || et2.getText().toString().trim().equals("+"))
		{
			Toast.makeText(getApplicationContext(), "Please Enter Numbers", 
					   Toast.LENGTH_LONG).show();
		}
		else if(v.getId()==R.id.button1)
		{
			Log.d("Inclass2A", "Inside Add");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())+Float.parseFloat(et2.getText().toString())));
		}
		else if(v.getId()==R.id.button2)
		{
			Log.d("Inclass2A", "Inside Subtract");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())-Float.parseFloat(et2.getText().toString())));
		}
		else if(v.getId()==R.id.button3)
		{
			Log.d("Inclass2A", "Inside Multiply");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())*Float.parseFloat(et2.getText().toString())));
		}
		else if(v.getId()==R.id.button4)
		{
			
			if(et2.getText().toString().equals("0"))
			{
				Toast.makeText(getApplicationContext(), "Cannot Divide by Zero", 
						   Toast.LENGTH_LONG).show();
			}
			else{
			Log.d("Inclass2A", "Inside Divide");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())/Float.parseFloat(et2.getText().toString())));
			}
		}
		
	}
}
