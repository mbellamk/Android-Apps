package com.example.inclass2b;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Assignment No: InClass Assignment02 - Part B 
 * File Name: MainActivity.java 
 * 
 * Team Members: 
 * 1. Manju Raghavendra Bellamkonda 
 * 2. Prem kumar Murugesan
 * 3. Madhavi bhat
 */
public class MainActivity extends Activity implements View.OnClickListener  {

	TextView tv;
	EditText et1;
	EditText et2;
	RadioGroup rg;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tv=(TextView) findViewById(R.id.textView2);
		et1=(EditText) findViewById(R.id.editText1);
		et2=(EditText) findViewById(R.id.editText2);
		Log.d("Inclass2B", "@@@@@@Inside OnCreate");
		
		rg=(RadioGroup) findViewById(R.id.radioGroup1);
	
		Button b1=(Button) findViewById(R.id.button1);
		b1.setOnClickListener(this);
	}


	@Override
	public void onClick(View v) {
		int checkedId=rg.getCheckedRadioButtonId();
		if(checkedId==R.id.radio4)
		{
			Log.d("Inclass2B", "Inside Onclick");
			et1.setText(null);
			et2.setText(null);
			tv.setText(null);
		}
		else if(et1.getText().toString().trim().equals("") || et2.getText().toString().trim().equals("") || et1.getText().toString().trim().equals("-") || et2.getText().toString().trim().equals("-")|| et1.getText().toString().trim().equals("+") || et2.getText().toString().trim().equals("+"))
		{
			Toast.makeText(getApplicationContext(), "Please Enter Numbers", 
					   Toast.LENGTH_LONG).show();
		}
		else if(checkedId==R.id.radio0)
		{
			Log.d("Inclass2B", "Inside Add");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())+Float.parseFloat(et2.getText().toString())));
		}
		else if(checkedId==R.id.radio1)
		{
			Log.d("Inclass2B", "Inside Subtract");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())-Float.parseFloat(et2.getText().toString())));
		}
		else if(checkedId==R.id.radio2)
		{
			Log.d("Inclass2B", "Inside Multiply");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())*Float.parseFloat(et2.getText().toString())));
		}
		else if(checkedId==R.id.radio3)
		{
			if(et2.getText().toString().equals("0"))
			{
				Toast.makeText(getApplicationContext(), "Cannot Divide by Zero", 
						   Toast.LENGTH_LONG).show();
			}
			else{
			Log.d("Inclass2B", "Inside Divide");
			tv.setText(Float.toString(Float.parseFloat(et1.getText().toString())/Float.parseFloat(et2.getText().toString())));
			}
		}

		
	}
}
